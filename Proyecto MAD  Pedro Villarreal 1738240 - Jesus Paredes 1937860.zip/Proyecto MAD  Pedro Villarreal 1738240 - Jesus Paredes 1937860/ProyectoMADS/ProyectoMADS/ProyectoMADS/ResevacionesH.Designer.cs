﻿namespace ProyectoMADS
{
    partial class ResevacionesH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.labelchingon = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.RFCC = new System.Windows.Forms.TextBox();
            this.FechaInicio = new System.Windows.Forms.DateTimePicker();
            this.FechaFin = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Combopais = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.Listaciudad = new System.Windows.Forms.ComboBox();
            this.Tipodepago = new System.Windows.Forms.ComboBox();
            this.Anticipo = new System.Windows.Forms.TextBox();
            this.Personas = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(37, 146);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.ShowCellErrors = false;
            this.dataGridView2.ShowCellToolTips = false;
            this.dataGridView2.ShowEditingIcon = false;
            this.dataGridView2.ShowRowErrors = false;
            this.dataGridView2.Size = new System.Drawing.Size(365, 210);
            this.dataGridView2.TabIndex = 6;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(400, 146);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.ShowCellErrors = false;
            this.dataGridView1.ShowCellToolTips = false;
            this.dataGridView1.ShowEditingIcon = false;
            this.dataGridView1.ShowRowErrors = false;
            this.dataGridView1.Size = new System.Drawing.Size(308, 210);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(34, 31);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 13);
            this.label9.TabIndex = 58;
            this.label9.Text = "RFC";
            // 
            // labelchingon
            // 
            this.labelchingon.AutoSize = true;
            this.labelchingon.Location = new System.Drawing.Point(105, 457);
            this.labelchingon.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelchingon.Name = "labelchingon";
            this.labelchingon.Size = new System.Drawing.Size(0, 13);
            this.labelchingon.TabIndex = 57;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(532, 72);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 13);
            this.label11.TabIndex = 56;
            this.label11.Text = "Fecha fin";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(348, 72);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 13);
            this.label10.TabIndex = 55;
            this.label10.Text = "Fecha inicio";
            // 
            // RFCC
            // 
            this.RFCC.Location = new System.Drawing.Point(37, 49);
            this.RFCC.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RFCC.Name = "RFCC";
            this.RFCC.Size = new System.Drawing.Size(238, 20);
            this.RFCC.TabIndex = 1;
            // 
            // FechaInicio
            // 
            this.FechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.FechaInicio.Location = new System.Drawing.Point(350, 97);
            this.FechaInicio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FechaInicio.Name = "FechaInicio";
            this.FechaInicio.Size = new System.Drawing.Size(158, 20);
            this.FechaInicio.TabIndex = 4;
            // 
            // FechaFin
            // 
            this.FechaFin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.FechaFin.Location = new System.Drawing.Point(535, 97);
            this.FechaFin.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FechaFin.Name = "FechaFin";
            this.FechaFin.Size = new System.Drawing.Size(158, 20);
            this.FechaFin.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(398, 122);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 13);
            this.label8.TabIndex = 51;
            this.label8.Text = "Habitaciones";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Cursor = System.Windows.Forms.Cursors.Default;
            this.label7.Location = new System.Drawing.Point(34, 82);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 50;
            this.label7.Text = "Ciudad";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(244, 370);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 45;
            this.label5.Text = "Tipo de pago:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(450, 370);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 43;
            this.label4.Text = "Aniticipo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 370);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 13);
            this.label2.TabIndex = 42;
            this.label2.Text = "Numero de personas:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(348, 31);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 41;
            this.label3.Text = "Pais";
            // 
            // Combopais
            // 
            this.Combopais.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Combopais.FormattingEnabled = true;
            this.Combopais.Location = new System.Drawing.Point(350, 47);
            this.Combopais.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Combopais.Name = "Combopais";
            this.Combopais.Size = new System.Drawing.Size(238, 21);
            this.Combopais.TabIndex = 2;
            this.Combopais.SelectedIndexChanged += new System.EventHandler(this.Combopais_SelectedIndexChanged);
            this.Combopais.SelectionChangeCommitted += new System.EventHandler(this.Combopais_SelectionChangeCommitted);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 122);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 38;
            this.label1.Text = "Hoteles";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(36, 440);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(220, 46);
            this.button2.TabIndex = 11;
            this.button2.Text = "Hacer reservacion";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Listaciudad
            // 
            this.Listaciudad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Listaciudad.FormattingEnabled = true;
            this.Listaciudad.Location = new System.Drawing.Point(37, 98);
            this.Listaciudad.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Listaciudad.Name = "Listaciudad";
            this.Listaciudad.Size = new System.Drawing.Size(238, 21);
            this.Listaciudad.TabIndex = 3;
            this.Listaciudad.SelectedIndexChanged += new System.EventHandler(this.Listaciudad_SelectedIndexChanged);
            this.Listaciudad.SelectionChangeCommitted += new System.EventHandler(this.Listaciudad_SelectionChangeCommitted);
            // 
            // Tipodepago
            // 
            this.Tipodepago.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Tipodepago.FormattingEnabled = true;
            this.Tipodepago.Items.AddRange(new object[] {
            "Tarjeta Master Card",
            "Tarjeta VISA",
            "Efectivo"});
            this.Tipodepago.Location = new System.Drawing.Point(247, 396);
            this.Tipodepago.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Tipodepago.Name = "Tipodepago";
            this.Tipodepago.Size = new System.Drawing.Size(188, 21);
            this.Tipodepago.TabIndex = 9;
            // 
            // Anticipo
            // 
            this.Anticipo.Location = new System.Drawing.Point(450, 396);
            this.Anticipo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Anticipo.Name = "Anticipo";
            this.Anticipo.Size = new System.Drawing.Size(191, 20);
            this.Anticipo.TabIndex = 10;
            // 
            // Personas
            // 
            this.Personas.Location = new System.Drawing.Point(41, 397);
            this.Personas.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Personas.Name = "Personas";
            this.Personas.Size = new System.Drawing.Size(188, 20);
            this.Personas.TabIndex = 8;
            // 
            // ResevacionesH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(727, 542);
            this.Controls.Add(this.Personas);
            this.Controls.Add(this.Anticipo);
            this.Controls.Add(this.Listaciudad);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.labelchingon);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.RFCC);
            this.Controls.Add(this.FechaInicio);
            this.Controls.Add(this.FechaFin);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Tipodepago);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Combopais);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ResevacionesH";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.ResevacionesH_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label labelchingon;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox RFCC;
        private System.Windows.Forms.DateTimePicker FechaInicio;
        private System.Windows.Forms.DateTimePicker FechaFin;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Combopais;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox Listaciudad;
        private System.Windows.Forms.ComboBox Tipodepago;
        private System.Windows.Forms.TextBox Anticipo;
        private System.Windows.Forms.TextBox Personas;
    }
}