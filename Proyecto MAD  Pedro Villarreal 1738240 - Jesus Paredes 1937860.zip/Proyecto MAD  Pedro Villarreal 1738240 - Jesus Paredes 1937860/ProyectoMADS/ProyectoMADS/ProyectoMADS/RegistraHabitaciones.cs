﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoMADS
{
    public partial class RegistraHabitaciones : Form
    {
        public enlace conexion;
        public RegistraHabitaciones()
        {
            InitializeComponent();
        }

        private void RegistraHabitaciones_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {


                int caso = 1;
                conexion = new enlace();
                int indiceN = NHABITACION.SelectedIndex;
                int indiceC = NoCAMAS.SelectedIndex + 1;
                int indiceTP = TCAMA.SelectedIndex;
                int indiceNO = NOPERSONAS.SelectedIndex + 1;
                int indiceU = UBICACION.SelectedIndex;


                float Precio = float.Parse(PRECIO.Text);
                string Habitaciones = NHABITACION.Items[indiceN].ToString();
                int nocamas = indiceC;
                string tipocam = TCAMA.Items[indiceTP].ToString();
                int indiceNUM = indiceNO;
                string UBICACIONH = UBICACION.Items[indiceU].ToString();


                conexion.insert_habitaciones(Habitaciones, tipocam, nocamas, Precio, UBICACIONH, indiceNUM, caso);
                conexion = null;

                NHABITACION.SelectedIndex = 0;
                NoCAMAS.SelectedIndex = 0;
                TCAMA.SelectedIndex = 0;
                NOPERSONAS.SelectedIndex = 0;
                UBICACION.SelectedIndex = 0;
                PRECIO.Text = "";


                MessageBox.Show("La informacion ha sido agregada exitosamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            catch (FormatException)
            {

                 MessageBox.Show("si ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
        }
    }
}
