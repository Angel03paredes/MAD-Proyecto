﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace ProyectoMADS
{
    
    public partial class DIalogoLogin : Form
    {
        string usuario = ConfigurationManager.AppSettings["usuario"];
        string contraseña = ConfigurationManager.AppSettings["contraseña"];

        public enlace conexion;
        DialogoMenu nombre = new DialogoMenu();
        public DIalogoLogin()
        {
            InitializeComponent();
        }

        private void DIalogoLogin_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try {
                DialogoMenu MENU = new DialogoMenu();
                MENU.Owner = this;
                int indice = comboBox1.SelectedIndex;
                if (indice == 0)
                {
                    if (textBox1.Text == usuario && textBox2.Text == contraseña)
                    {


                        nombre.label2.Text = comboBox1.Items[indice].ToString();
                        
                        nombre.Show();
                 


                    }
                    else
                        MessageBox.Show("ERROR INGRESA LOS DATOS CORRECTOS ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);


                }
                else
                {
                    bool creado;

                    conexion = new enlace();
                    int variable = int.Parse(textBox1.Text);
                    creado = conexion.LOGIN(variable, textBox2.Text);

                    if (creado == true)
                    {
                        nombre.label2.Text = comboBox1.Items[indice].ToString();
                        nombre.nomina.Text = textBox1.Text;
                        
                        nombre.Show();
                       
                    }
                    else
                    {

                        MessageBox.Show("ERROR INGRESA LOS DATOS CORRECTOS ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }

                }






                conexion = null;














            }
            catch (Exception ex)
            {
                MessageBox.Show("Ingresa los datos correctamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
      
           


          

        }
    }
    }

