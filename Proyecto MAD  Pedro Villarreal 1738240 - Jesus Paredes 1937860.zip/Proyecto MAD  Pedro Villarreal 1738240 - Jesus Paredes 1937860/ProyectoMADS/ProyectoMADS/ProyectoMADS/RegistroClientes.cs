﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoMADS
{
    public partial class RegistroClientes : Form
    {
        public enlace conexion;
        public RegistroClientes()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void RegistroClientes_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                conexion = new enlace();
                long telefonoCel = long.Parse(TELCEL.Text);
                long telefonoCA = long.Parse(TELCASA.Text);
                 string nombres = Nombre.Text;
                string paternos = Paterno.Text;
                string maternos = Materno.Text;
                   string erefc = RFC.Text;
                 string correos = CORREO.Text;
                
                  string fechap = FECHANA.Text;
                     string Dom = DOMICILIO.Text;
                    string Desc = DESCRIPCION.Text;
                DataTable Retorna = new DataTable();
           Retorna  =  conexion.insert_clientes(nombres, paternos, maternos, erefc, correos, telefonoCA, telefonoCel, fechap, Dom, Desc);

                dataGridView1.DataSource = Retorna;

                conexion = null;
                TELCEL.Text = "";
                TELCASA.Text = "";
                Nombre.Text="";
                Paterno.Text="";
                Materno.Text="";
                RFC.Text="";
                CORREO.Text="";

                FECHANA.Text="";
                DOMICILIO.Text="";
                DESCRIPCION.Text = "";

                MessageBox.Show("La informacion ha sido agregada exitosamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            catch (FormatException)
            {

                MessageBox.Show("Ingresa los datos correctamente.", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);


            }
 


        }
    }
}
