﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoMADS
{
    public partial class RegistroUserH : Form
    {
        public enlace conexion;
        public RegistroUserH()
        {
            InitializeComponent();
        }

        private void RegistroUserH_Load(object sender, EventArgs e)
        { try
            {

                conexion = new enlace();
                DataTable data = new DataTable();


                data = conexion.get_Pais();


                comboBox1.DataSource = data;
                // dataGridView1.DataSource = data;

                comboBox1.DisplayMember = "abrev";
                comboBox1.ValueMember = "clave_pais";
                comboBox1.Text = "";
                conexion = null;

            }
            catch (FormatException)
            {

                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
         

        }

        private void button1_Click(object sender, EventArgs e)
        { 
            try
            {
                conexion = new enlace();
                int indice = comboBox1.SelectedIndex + 1;
                int nomina = Int32.Parse(label4.Text);
                //  string si = comboBox1.Items[indice].ToString();
                int pais = indice;
                conexion.Agregar_Pais(nomina, pais);
                MessageBox.Show("La informacion ha sido agregada exitosamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);





                conexion = null;

            }
            catch (FormatException)
            {

                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }

   
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
