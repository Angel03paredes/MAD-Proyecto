﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;
namespace ProyectoMADS
{
    public partial class CheckOut : Form
    {
        int globalon;
        public enlace conexion;
        string clave_h = "";
        string clave_C = "";
        string clave_P = "";
        string clave_A = "";
        string  CANTP  = "";
        string ADELANTO = "";
        bool condicion = true;
        int Multiplica;
        float MONTO;
        string pago_total = "";
        string precioxnoche = "";
        string hotel = "";
        string domicilio = "";
        string ciudad = "";
        string nombre = "";
        string apellidop = "";
        string apellidom = "";
        string folio = "";
        string servicio = "";
        string costoservicio = "";
        string anticipo = "";
        string forma_depago = "";
        List<object> list = new List<object>();
        public CheckOut()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)

        {
            try
            {
                conexion = new enlace();
                int id = int.Parse(textBox1.Text);
                int id2 = comboBox1.SelectedIndex;
                string rola = comboBox1.Items[id2].ToString();
                conexion.Checkout(id, rola);
                condicion = true;
            }
            catch (FormatException)
            {


            }
         
        }

        private void CheckOut_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            conexion = new enlace();
            DataTable Checkafuera = new DataTable();

            try
            {

                int jj = int.Parse(textBox1.Text);



                Checkafuera = conexion.Checkout(jj);


                dataGridView1.DataSource = Checkafuera;
                clave_P = dataGridView1.Rows[0].Cells["PRECIOS"].FormattedValue.ToString();
                CANTP = dataGridView1.Rows[0].Cells["PERSONAS"].FormattedValue.ToString();
                ADELANTO = dataGridView1.Rows[0].Cells["ADELANTO"].FormattedValue.ToString();
                float adelanta = float.Parse(ADELANTO);
                float precio = float.Parse(clave_P);
                int CANTPERSONAS = int.Parse(CANTP);


             
                textBox3.Text = ADELANTO.ToString();
                textBox4.Text = MONTO.ToString();
                float adelanto = float.Parse(ADELANTO);
                restarrr.Text = (MONTO - adelanto).ToString();

            }
            catch (Exception)
            {
                MessageBox.Show("ERROR ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);


            }







            conexion = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {


            try
            {




                conexion = new enlace();

                int idS = int.Parse(textBox1.Text); // NUMERO RESERVACION
                int idC = int.Parse(textBox2.Text);  // CANTIDAD
                int str = int.Parse(clave_h);   // ID SERVICIO
                float CLAVEC = float.Parse(clave_C);
                int multiplica = int.Parse(clave_A);
                float precio = float.Parse(clave_P);
                float adelanto = float.Parse(ADELANTO);
                int CANTPERSONAS = int.Parse(CANTP);
                conexion.PAGA(idS, str, idC);

                if(condicion== true)
                {
                  MONTO = (multiplica * (CANTPERSONAS * precio))-adelanto;
                    condicion = false;
                }
               


                    MONTO += (idC * CLAVEC);
                    textBox4.Text = MONTO.ToString();

                    conexion = null;

                
                restarrr.Text = (MONTO - adelanto).ToString();

           

            }
            catch (FormatException)
            {
                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }












        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {



            try
            {

                if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    dataGridView1.CurrentRow.Selected = true;
                    clave_h = dataGridView1.Rows[e.RowIndex].Cells["Identificador"].FormattedValue.ToString();
                    clave_C = dataGridView1.Rows[e.RowIndex].Cells["Costo"].FormattedValue.ToString();
                    clave_A = dataGridView1.Rows[e.RowIndex].Cells["DIAS"].FormattedValue.ToString();
                    ///clave_P = dataGridView1.Rows[e.RowIndex].Cells["PRECIOS"].FormattedValue.ToString();
                    //CANTP = dataGridView1.Rows[e.RowIndex].Cells["PERSONAS"].FormattedValue.ToString();


                }

            }
            catch (FormatException)
            {
                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }









            
        }

        private void Adelanto(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                conexion = new enlace();
                int str = int.Parse(textBox1.Text);
                DataTable data = new DataTable();
                conexion.FINALIZA(str, MONTO);

                DialogResult pdf = MessageBox.Show("Desea Pedir Factura?", "FACTURA", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (pdf == DialogResult.OK)
                {
                    data = conexion.Factura(str);










                    foreach (DataRow dr in data.Rows)
                    {

                        list.Add(dr);


                    }

                    foreach (DataRow dr in list)
                    {

                         pago_total = dr.ItemArray[0].ToString();
                         precioxnoche = dr.ItemArray[1].ToString();
                         hotel = dr.ItemArray[2].ToString();
                         domicilio = dr.ItemArray[3].ToString();
                         ciudad = dr.ItemArray[4].ToString();
                         nombre = dr.ItemArray[5].ToString();
                         apellidop = dr.ItemArray[6].ToString();
                         apellidom = dr.ItemArray[7].ToString();
                         folio = dr.ItemArray[8].ToString();
                         servicio = dr.ItemArray[9].ToString();
                         costoservicio = dr.ItemArray[10].ToString();
                         anticipo = dr.ItemArray[11].ToString();
                         forma_depago = dr.ItemArray[12].ToString();

                        

                    }
                    printDocument1 = new PrintDocument();
                    PrinterSettings ps = new PrinterSettings();
                    printDocument1.PrinterSettings = ps;
                    printDocument1.PrintPage += IMPRIMIR;
                    printDocument1.Print();


                    button2.Enabled = false;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Ingresa los datos correctamente", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }



         
        }

        private void IMPRIMIR(object sender, PrintPageEventArgs e)
        {
            Font font = new Font("Arial", 14);
            int ancho = 300;
            int y = 20;






            e.Graphics.DrawString("Nombre: " + nombre, font, Brushes.Black, new RectangleF(0, y + 40, ancho, 20));

            e.Graphics.DrawString("Apellido Paterno: " + apellidop, font, Brushes.Black, new RectangleF(0, y + 60, ancho, 20));

            e.Graphics.DrawString("Apellido Materno: " + apellidom, font, Brushes.Black, new RectangleF(0, y + 80, ancho, 20));

            e.Graphics.DrawString("Domicilio: " + domicilio, font, Brushes.Black, new RectangleF(0, y + 100, ancho, 20));
           
            e.Graphics.DrawString("Ciudad: " + ciudad, font, Brushes.Black, new RectangleF(0, y + 120, ancho, 20));

            e.Graphics.DrawString("Hotel: " + hotel, font, Brushes.Black, new RectangleF(0, y + 140, ancho, 20));

            e.Graphics.DrawString("Folio: " + folio, font, Brushes.Black, new RectangleF(0, y + 160, ancho, 20));

            e.Graphics.DrawString("Forma de pago: " + forma_depago, font, Brushes.Black, new RectangleF(0, y + 180, ancho,20));

            e.Graphics.DrawString("Anticipo: " + anticipo, font, Brushes.Black, new RectangleF(0, y + 200, ancho, 20));

        
            int camaleon = 240;
            int otroint = 260;

            foreach (DataRow dr in list)
            {      
                servicio = dr.ItemArray[9].ToString();
                 costoservicio = dr.ItemArray[10].ToString();

                if (camaleon == 240 && otroint == 260)
                {

                

                    e.Graphics.DrawString("Servicios: " + servicio, font, Brushes.Black, new RectangleF(0, y + camaleon, ancho, 20));
                    e.Graphics.DrawString("Costo del servicio: " + costoservicio, font, Brushes.Black, new RectangleF(0, y + otroint, ancho, 20));

                    camaleon += 40;
                    otroint += 40;
                }
            else
            {
                


                    e.Graphics.DrawString("Servicios: " + servicio, font, Brushes.Black, new RectangleF(0, y + camaleon, ancho, 20));
                    e.Graphics.DrawString("Costo del servicio: " + costoservicio, font, Brushes.Black, new RectangleF(0, y + otroint, ancho, 20));
                    camaleon += 40;
                    otroint += 40;

                }
              

            
            }



            e.Graphics.DrawString("Total: " + pago_total, font, Brushes.Black, new RectangleF(0, y + otroint + 20, ancho, 20));

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        
    }
}
