﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;


namespace ProyectoMADS
{
    public partial class ResevacionesH : Form
    {
        string claveh;
        string claveh2;
        int indice2;
        int indice;


        public  enlace conexion;
        public ResevacionesH()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void ResevacionesH_Load(object sender, EventArgs e)
        {
            try
            {
                int nomina = int.Parse(labelchingon.Text);
                conexion = new enlace();

                DataTable NuevaTabla = new DataTable();
                NuevaTabla = conexion.get_Pais2(nomina);



                Combopais.DataSource = NuevaTabla;

                Combopais.DisplayMember = "pais";
                Combopais.ValueMember = "clave";
                Combopais.Text = "";



                conexion = null;
            }


            catch (Exception ex)
            {
                MessageBox.Show("Ingresa los datos correctamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // int indicepais = Combopais.SelectedIndex
                int indiceTipoPago = Tipodepago.SelectedIndex;
                int indiceCiudad = Listaciudad.SelectedIndex;

                string CLIENTERFC = RFCC.Text;
                int Numeropersonas = int.Parse(Personas.Text);

                float anticip = float.Parse(Anticipo.Text);
                string Pago = Tipodepago.Items[indiceTipoPago].ToString();
                //string Ciudad = Listaciudad.Items[indiceCiudad].ToString();
                //string hotel = listahotel.Items[indice]
                string FechaI = FechaInicio.Text;
                string FechaF = FechaFin.Text;
                string habitacion = claveh2;
                string nombreH = claveh;
                DataTable LATABLA = new DataTable();






                LATABLA = conexion.InsertReservaciones(CLIENTERFC, Numeropersonas, anticip, Pago, FechaI, FechaF, habitacion, nombreH);
                MessageBox.Show("La reservacion ha sido efectuada exitosamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                FechaInicio.Text = "";
                FechaFin.Text = "";
                RFCC.Text = "";
                Tipodepago.SelectedIndex = 0;
                Listaciudad.SelectedIndex = 0;
                Personas.Text = "";
                Anticipo.Text = "";

                List<object> list = new List<object>();

                string pp = "";
                string corr = "";





                foreach (DataRow dr in LATABLA.Rows)
                {

                    list.Add(dr);


                }

                foreach (DataRow dr in list)
                {

                    pp = dr.ItemArray[0].ToString();
                    corr = dr.ItemArray[1].ToString();
                    MessageBox.Show(pp, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    MailMessage email = new MailMessage();
                    email.To.Add(new MailAddress(corr));
                    email.From = new MailAddress("hoteleslmad@gmail.com");
                    email.Subject = "Asunto ( " + DateTime.Now.ToString("dd / MMM / yyy hh:mm:ss") + " ) ";
                    email.Body = "Numero de reservacion :  " + pp ;
                    email.IsBodyHtml = true;
                    email.Priority = MailPriority.Normal;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.Port = 587;
                    smtp.EnableSsl = true;
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential("hoteleslmad@gmail.com", "SQLSERVER");

                   
                    try
                    {
                        smtp.Send(email);
                        email.Dispose();
                 
                    }
                    catch (Exception ex)
                    {
                       // MessageBox.Show("Correo no enviado ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }

                   

                }




                conexion = null;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Correo no enviado o datos incorrectos", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }



        }



        private void Combopais_SelectedIndexChanged(object sender, EventArgs e)
        {

           



        }

        private void Combopais_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                conexion = new enlace();
                DataTable data5 = new DataTable();
                indice2 = int.Parse(Combopais.SelectedValue.ToString());

                data5 = conexion.get_Ciudad(indice2);


                Listaciudad.DataSource = data5;


                Listaciudad.DisplayMember = "nombre";
                Listaciudad.ValueMember = "clave_ciudad";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ingresa los datos correctamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }




        }

        private void Listaciudad_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try {

                conexion = new enlace();
                DataTable data5 = new DataTable();
                indice = int.Parse(Listaciudad.SelectedValue.ToString());

                data5 = conexion.get_Hotel_R(indice);


                dataGridView2.DataSource = data5;


            }
            catch (Exception ex)
            {
                MessageBox.Show("Ingresa los datos correctamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }


        }

        private void Listaciudad_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {   try {
            if (dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                dataGridView2.CurrentRow.Selected = true;
                claveh = dataGridView2.Rows[e.RowIndex].Cells["Hotel"].FormattedValue.ToString();
            
               // long indiceP =long.Parse(F)
                // INDICE COMBO BOX PAIS  E INDICE COMBO BOX DE CIUDAD
                                     string DATE1 = FechaInicio.Text;
                                     string DATE2 = FechaFin.Text;
                // PAIS 

                // CIUDAD
                DataTable Habitationes = new DataTable();
                
               Habitationes = conexion.get_habitacion_R(DATE1,DATE2,claveh, indice2, indice);

                dataGridView1.DataSource = Habitationes;

           





            }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ingresa los datos correctamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }



        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    dataGridView1.CurrentRow.Selected = true;
                    claveh2 = dataGridView1.Rows[e.RowIndex].Cells["Tipo"].FormattedValue.ToString();

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ingresa los datos correctamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }



        }

        private void Capacidad_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //  
          //  
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
