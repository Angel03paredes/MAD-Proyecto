﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoMADS
{
    public partial class ReporteV : Form
    {
        public enlace conexion;
        public ReporteV()
        {
            InitializeComponent();
        }

        private void ReporteV_Load(object sender, EventArgs e)
        {  try
            {
                conexion = new enlace();
                DataTable data = new DataTable();

                data = conexion.get_Pais();

                PAIS.DataSource = data;
                // dataGridView1.DataSource = data;

                PAIS.DisplayMember = "abrev";
                PAIS.ValueMember = "clave_pais";
                PAIS.Text = "";

                dateTimePicker1.Format = DateTimePickerFormat.Custom;
                dateTimePicker1.CustomFormat = "MM/yyyy";

                conexion = null;

            }
            catch (FormatException)
            {

                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
           

        }

        private void button1_Click(object sender, EventArgs e)
        { try
            {
                conexion = new enlace();
                DataTable tabla = new DataTable();
                int opcion = 3;
                int CASO = comboBox1.SelectedIndex + 1;

                int PAISES = 0;
                PAISES = int.Parse(PAIS.SelectedValue.ToString());
                string MES = dateTimePicker1.Text;

                tabla = conexion.ReporteV(PAISES, MES, CASO, opcion);

                dataGridView2.DataSource = tabla;

            }
            catch (FormatException)
            {

                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
          

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
