﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace ProyectoMADS
{
    public class enlace
    {
        static private string _aux { set; get; }
        static private SqlConnection _conexion;
        static private DataTable _tabla = new DataTable();
        static private DataSet _DS = new DataSet();
        static private SqlDataAdapter _adaptador = new SqlDataAdapter();
        static private SqlCommand _comandosql = new SqlCommand();

        public DataTable obtenertabla
        {
            get
            {
                return _tabla;
            }
        }

        private static void conectar()
        {
            // string cnn = ConfigurationManager.AppSettings["desarrollo1"];
            string cnn = ConfigurationManager.ConnectionStrings["claseMAD_A"].ToString();
            // string cnn = ConfigurationManager.ConnectionStrings["MAD"].ConnectionString;

            _conexion = new SqlConnection(cnn);
            //  _conexion.Open();
            // MessageBox.Show("SI se conecto");
            // _conexion.Close();

        }
        private static void desconectar()
        {
            _conexion.Close();
        }
        public bool LOGIN(int usuario, string contra)
        {
            bool isValid = false;
            try
            {
                conectar();
                string qry = "SP_LOGIN";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 9000;

                var parametro1 = _comandosql.Parameters.Add("@usuario", SqlDbType.Int, 0);
                parametro1.Value = usuario;
                var parametro2 = _comandosql.Parameters.Add("@contra", SqlDbType.VarChar, 20);
                parametro2.Value = contra;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(_tabla);

                if (_tabla.Rows.Count > 0)
                {
                    isValid = true;
                }

            }
            catch (SqlException e)
            {
                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                isValid = false;
            }
            finally
            {
                desconectar();
            }

            return isValid;
        }
        public void Actualizar_User(string nombre, string contra, string apellido, int nomina, string fecha, long telcasa, long telcel, string domicilio)
        {
            int caso = 4;
            try
            {
                conectar();
                string qry = "SP_USUARIO";

                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 9000;

                var parametro1 = _comandosql.Parameters.Add("@contra", SqlDbType.VarChar, 20);
                parametro1.Value = contra;
                var parametro2 = _comandosql.Parameters.Add("@nombre", SqlDbType.VarChar, 50);
                parametro2.Value = nombre;
                var parametro3 = _comandosql.Parameters.Add("@apellido", SqlDbType.VarChar, 50);
                parametro3.Value = apellido;
                var parametro4 = _comandosql.Parameters.Add("@no_nomina", SqlDbType.BigInt, 0);
                parametro4.Value = nomina;
                var parametro5 = _comandosql.Parameters.Add("@fecha_nac", SqlDbType.DateTime, 50);
                parametro5.Value = fecha;
                var parametro6 = _comandosql.Parameters.Add("@domicilio", SqlDbType.VarChar, 50);
                parametro6.Value = domicilio;
                var parametro7 = _comandosql.Parameters.Add("@tel_casa", SqlDbType.BigInt, 0);
                parametro7.Value = telcasa;
                var parametro8 = _comandosql.Parameters.Add("@tel_cel", SqlDbType.BigInt, 0);
                parametro8.Value = telcel;
                var parametro9 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro9.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(_tabla);



            }
            catch (SqlException e)
            {

                var msg = "";
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
            finally
            {
                desconectar();
            }


        }

        public void Actuali(int cl_res,int caso)
        {
            
            try
            {
                conectar();
                string qry = "SP_RESERVACION";

                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 9000;

                var parametro1 = _comandosql.Parameters.Add("@cl_res", SqlDbType.BigInt,0);
                parametro1.Value = cl_res;

                var parametro9 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro9.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(_tabla);



            }
            catch (SqlException e)
            {

                var msg = "";
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
            finally
            {
                desconectar();
            }


        }
        public void Checkout(int id,string pago)
        {
            int caso = 6;
            try
            {
                conectar();
                string qry = "SP_RESERVACION";

                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 9000;

                var parametro1 = _comandosql.Parameters.Add("@id", SqlDbType.BigInt, 0);
                parametro1.Value = id;

                var parametro2 = _comandosql.Parameters.Add("@pago", SqlDbType.BigInt, 0);
                parametro2.Value = pago;

                var parametro3 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro3.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(_tabla);



            }
            catch (SqlException e)
            {

                var msg = "";
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
            finally
            {
                desconectar();
            }


        }


        public DataTable get_usuarios()
        {
            int caso = 2;
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SP_USUARIO";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro8 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro8.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }

        public DataTable Delete_users(int nomina)
        {        //DELETE FROM usuario WHERE no_nomina  = @no_nomina
            var msg = "";
            int caso = 3;

            try

            { conectar();

                string qry = "SP_USUARIO";



                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;


                var parametro = _comandosql.Parameters.Add("@no_nomina", SqlDbType.BigInt, 0);
                parametro.Value = nomina;
                var parametro2 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro2.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(_tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return _tabla;
        }
        public void insert_habitaciones(string nivel, string Tcamas, int no_camas, float preciox, string Ubicacion, int Npersonas, int caso)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {

                conectar();
                string qry = "SP_THabitaciones";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@nivel", SqlDbType.VarChar, 50);
                parametro1.Value = nivel;
                var parametro2 = _comandosql.Parameters.Add("@Tcamas", SqlDbType.VarChar, 50);
                parametro2.Value = Tcamas;
                var parametro3 = _comandosql.Parameters.Add("@no_camas", SqlDbType.BigInt, 0);
                parametro3.Value = no_camas;
                var parametro4 = _comandosql.Parameters.Add("@preciox", SqlDbType.Money, 0);
                parametro4.Value = preciox;
                var parametro5 = _comandosql.Parameters.Add("@Ubicacion", SqlDbType.VarChar, 50);
                parametro5.Value = Ubicacion;

                var parametro6 = _comandosql.Parameters.Add("@Npersonas", SqlDbType.BigInt, 0);
                parametro6.Value = Npersonas;
                var parametro7 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro7.Value = caso;



                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

        }

        //CIUDAD  //ZONAT                         //PLAYA                        //PISC
        public void insert_hoteles(string Name, string Address, int City, int ZoneT, int Floor, int Beach, int ELIGEP, string DATE, int PISC, int Room, int caso)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {

                conectar();
                string qry = "SP_HOTEL";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@Name", SqlDbType.VarChar, 50);
                parametro1.Value = Name;
                var parametro2 = _comandosql.Parameters.Add("@Address", SqlDbType.VarChar, 50);
                parametro2.Value = Address;
                var parametro3 = _comandosql.Parameters.Add("@City", SqlDbType.BigInt, 0);
                parametro3.Value = City;
                var parametro4 = _comandosql.Parameters.Add("@ZoneT", SqlDbType.VarChar, 50);
                parametro4.Value = ZoneT;
                var parametro5 = _comandosql.Parameters.Add("@Floor", SqlDbType.BigInt, 0);
                parametro5.Value = Floor;

                var parametro6 = _comandosql.Parameters.Add("@Beach", SqlDbType.BigInt, 0);
                parametro6.Value = Beach;
                var parametro7 = _comandosql.Parameters.Add("@ELIGEP", SqlDbType.BigInt, 0);
                parametro7.Value = ELIGEP;
                var parametro8 = _comandosql.Parameters.Add("@DATE", SqlDbType.DateTime, 50);
                parametro8.Value = DATE;
                var parametro9 = _comandosql.Parameters.Add("@PISC", SqlDbType.BigInt, 0);
                parametro9.Value = PISC;
                var parametro10 = _comandosql.Parameters.Add("@Room", SqlDbType.BigInt, 0);
                parametro10.Value = Room;
                var parametro11 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro11.Value = caso;



                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);
                MessageBox.Show("La informacion ha sido agregada exitosamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

        }
        public void Agregar_Pais(int nomina, int pais)
        {
            int caso = 1;
            var msg = "";
            try
            {
                conectar();
                string qry = "SP_PAIS";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 9000;

                var parametro1 = _comandosql.Parameters.Add("@nomina", SqlDbType.BigInt, 0);
                parametro1.Value = nomina;
                var parametro2 = _comandosql.Parameters.Add("@idpais", SqlDbType.BigInt, 0);
                parametro2.Value = pais;
                var parametro3 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro3.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(_tabla);


            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }


        }
        public DataTable insert_usuario(string nombre, string contra, string apellido, int nomina, string fecha, long telcasa, long telcel, string domicilio)
        {
            int caso = 1;
            var msg = "";
            RegistroUserH mostrar_nomina = new RegistroUserH();
            DataTable tabla = new DataTable();
            try
            {

                conectar();
                string qry = "SP_USUARIO";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;
                //  _conexion.Open();
                // _comandosql.Parameters.AddWithValue("@nombre", nombre);
                //   _comandosql.ExecuteNonQuery();
                // _conexion.Close();

                var parametro1 = _comandosql.Parameters.Add("@contra", SqlDbType.VarChar, 20);
                parametro1.Value = contra;
                var parametro2 = _comandosql.Parameters.Add("@nombre", SqlDbType.VarChar, 50);
                parametro2.Value = nombre;
                var parametro3 = _comandosql.Parameters.Add("@apellido", SqlDbType.VarChar, 50);
                parametro3.Value = apellido;
                var parametro4 = _comandosql.Parameters.Add("@no_nomina", SqlDbType.BigInt, 0);
                parametro4.Value = nomina;
                var parametro5 = _comandosql.Parameters.Add("@fecha_nac", SqlDbType.DateTime, 50);
                parametro5.Value = fecha;
                var parametro6 = _comandosql.Parameters.Add("@domicilio", SqlDbType.VarChar, 50);
                parametro6.Value = domicilio;
                var parametro7 = _comandosql.Parameters.Add("@tel_casa", SqlDbType.BigInt, 0);
                parametro7.Value = telcasa;
                var parametro8 = _comandosql.Parameters.Add("@tel_cel", SqlDbType.BigInt, 0);
                parametro8.Value = telcel;
                var parametro9 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro9.Value = caso;


                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

                mostrar_nomina.label4.Text = nomina.ToString();
                mostrar_nomina.label3.Text = nombre;
                mostrar_nomina.Show();
            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }
        public DataTable get_Pais()
        {
            int caso = 2;
            try
            {
                conectar();
                string qry = "SP_PAIS";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 9000;

                var parametro8 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro8.Value = caso;
                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(_tabla);


            }
            catch (SqlException e)
            {

            }
            finally
            {
                desconectar();
            }

            return _tabla;
        }


        public DataTable get_Pais2(int nomina)
        {

            DataTable tabla = new DataTable();
            int caso = 2;
            try
            {
                conectar();
                string qry = "SP_RESERVACION";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 9000;

                var parametro8 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro8.Value = caso;
                var parametro9 = _comandosql.Parameters.Add("@nomina", SqlDbType.Int, 0);
                parametro9.Value = nomina;



                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);



            }
            catch (SqlException e)
            {
                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }
        public DataTable get_habitacion()
        {
            int caso = 2;
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SP_THabitaciones";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro8 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro8.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }


        public DataTable Checkout(int numero)
        {
           int caso = 6;
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SP_Reservacion";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;
                var parametro1 = _comandosql.Parameters.Add("@num_res", SqlDbType.BigInt, 0);
                parametro1.Value = numero;
                var parametro2 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro2.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);


                if (tabla == null)
                {

                    

                }

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla; 
        }
        public DataTable Obtener()
        {
            int caso = 7;
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SP_Reservacion";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;
                var parametro1 = _comandosql.Parameters.Add("@numres", SqlDbType.BigInt, 0);
                parametro1.Value = caso;
                var parametro2 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro2.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;



        }

        public void insert_servicio(float costo, string servicio)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                int caso = 3;

                conectar();
                string qry = "SP_HOTEL";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@costo", SqlDbType.Money, 0);
                parametro1.Value = costo;
                var parametro2 = _comandosql.Parameters.Add("@servicio", SqlDbType.VarChar, 50);
                parametro2.Value = servicio;
                var parametro3 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro3.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

        }
        public DataTable insert_clientes(string nombre, string apellidoP, string apellidoM, string RFC, string correo, long telcasa, long telcel, string FechaNA, string Referencia, string domicilio)
        {
            var msg = ""; 
            DataTable Nuevatabla = new DataTable();
            DataTable tabla = new DataTable();
            try
            {

                conectar();
                string qry = "SP_CLIENTE";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;
              
                var parametro1 = _comandosql.Parameters.Add("@nombre", SqlDbType.VarChar, 50);
                parametro1.Value = nombre;
                var parametro2 = _comandosql.Parameters.Add("@apellidoP", SqlDbType.VarChar, 50);
                parametro2.Value = apellidoP;
                var parametro3 = _comandosql.Parameters.Add("@apellidoM", SqlDbType.VarChar, 50);
                parametro3.Value = apellidoM;
                var parametro4 = _comandosql.Parameters.Add("@RFC", SqlDbType.VarChar, 50);
                parametro4.Value = RFC;
                var parametro5 = _comandosql.Parameters.Add("@correo", SqlDbType.VarChar, 50);
                parametro5.Value = correo;
                var parametro6 = _comandosql.Parameters.Add("@telcasa", SqlDbType.BigInt, 0);
                parametro6.Value = telcasa;

                var parametro7 = _comandosql.Parameters.Add("@telcel", SqlDbType.BigInt, 0);
                parametro7.Value = telcel;
                var parametro8 = _comandosql.Parameters.Add("@Fecha_NA", SqlDbType.DateTime, 0);
                parametro8.Value = FechaNA;
                var parametro9 = _comandosql.Parameters.Add("@Referencia", SqlDbType.VarChar, 100);
                parametro9.Value = Referencia;
                var parametro10 = _comandosql.Parameters.Add("@domicilio", SqlDbType.VarChar, 100);
                parametro10.Value = domicilio;





                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(Nuevatabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }
            return Nuevatabla;
        }


        public void insert_HAB(int veces, long hab)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                int caso = 4;
                conectar();
                string qry = "SP_HOTEL";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;


                var parametro5 = _comandosql.Parameters.Add("@veces", SqlDbType.BigInt, 0);
                parametro5.Value = veces;
                var parametro6 = _comandosql.Parameters.Add("@hab", SqlDbType.BigInt, 0);
                parametro6.Value = hab;
                var parametro7 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro7.Value = caso;



                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

        }

        public DataTable get_Ciudad(int idpais)
        {
            DataTable tabla = new DataTable();
            int caso = 3;
            try
            {
                conectar();
                string qry = "SP_PAIS";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 9000;

                var parametro7 = _comandosql.Parameters.Add("@idpais", SqlDbType.Int, 0);
                parametro7.Value = idpais;
                var parametro8 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro8.Value = caso;


                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);


            }
            catch (SqlException e)
            {

            }
            finally
            {
                desconectar();
            }

            return tabla;
        }

        public DataTable get_Hotel_R(int idciudad)
        {
            DataTable tabla = new DataTable();
            int caso = 3;
            try
            {
                conectar();
                string qry = "SP_RESERVACION";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 9000;

                var parametro7 = _comandosql.Parameters.Add("@clave_ciudad", SqlDbType.Int, 0);
                parametro7.Value = idciudad;
                var parametro8 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro8.Value = caso;


                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);


            }
            catch (SqlException e)
            {

            }
            finally
            {
                desconectar();
            }

            return tabla;
        }

        public DataTable get_hotel()
        {
            int caso = 2;
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SP_HOTEL";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro8 = _comandosql.Parameters.Add("@caso", SqlDbType.Int, 0);
                parametro8.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }

        public DataTable get_habitacion_R(string FECHAINICIO,string FECHAFIN,string CLAVEH, long indiceP,long indiceC)
        {
            int caso = 4;
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                    conectar();
                string qry = "SP_RESERVACION";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;
                //int clave = int.Parse(CLAVEH);



                var parametro1 = _comandosql.Parameters.Add("@fecha_ini", SqlDbType.DateTime, 50);
                parametro1.Value = FECHAINICIO;
                var parametro2 = _comandosql.Parameters.Add("@fecha_fin", SqlDbType.DateTime, 50);
                parametro2.Value = FECHAFIN;

                var parametro3 = _comandosql.Parameters.Add("@clave_hotel", SqlDbType.VarChar, 50);
                parametro3.Value = CLAVEH;

                var parametro4 = _comandosql.Parameters.Add("@clave_pais", SqlDbType.BigInt, 0);
                parametro4.Value = indiceP;

                var parametro5 = _comandosql.Parameters.Add("@clave_ciudad", SqlDbType.BigInt, 0);
                parametro5.Value = indiceC;
                var parametro6 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro6.Value =caso;



                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }

        public void actualizar_hoteles(string Name, string Address, int City, int ZoneT,
            int Floor, int Beach, int ELIGEP, string DATE, int PISC, int Room, int caso, int clave_h)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {

                conectar();
                string qry = "SP_HOTEL";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@Name", SqlDbType.VarChar, 50);
                parametro1.Value = Name;
                var parametro2 = _comandosql.Parameters.Add("@Address", SqlDbType.VarChar, 50);
                parametro2.Value = Address;
                var parametro3 = _comandosql.Parameters.Add("@City", SqlDbType.BigInt, 0);
                parametro3.Value = City;
                var parametro4 = _comandosql.Parameters.Add("@ZoneT", SqlDbType.VarChar, 50);
                parametro4.Value = ZoneT;
                var parametro5 = _comandosql.Parameters.Add("@Floor", SqlDbType.BigInt, 0);
                parametro5.Value = Floor;

                var parametro6 = _comandosql.Parameters.Add("@Beach", SqlDbType.BigInt, 0);
                parametro6.Value = Beach;
                var parametro7 = _comandosql.Parameters.Add("@ELIGEP", SqlDbType.BigInt, 0);
                parametro7.Value = ELIGEP;
                var parametro8 = _comandosql.Parameters.Add("@DATE", SqlDbType.DateTime, 50);
                parametro8.Value = DATE;
                var parametro9 = _comandosql.Parameters.Add("@PISC", SqlDbType.BigInt, 0);
                parametro9.Value = PISC;
                var parametro10 = _comandosql.Parameters.Add("@Room", SqlDbType.BigInt, 0);
                parametro10.Value = Room;
                var parametro11 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro11.Value = caso;

                var parametro12 = _comandosql.Parameters.Add("@hotel", SqlDbType.Int, 0);
                parametro12.Value = clave_h;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

        }


        public void actualizar_HAB(int veces, long hab, int hotel)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                int caso = 6;
                conectar();
                string qry = "SP_HOTEL";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;


                var parametro5 = _comandosql.Parameters.Add("@veces", SqlDbType.BigInt, 0);
                parametro5.Value = veces;
                var parametro6 = _comandosql.Parameters.Add("@hab", SqlDbType.BigInt, 0);
                parametro6.Value = hab;
                var parametro7 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro7.Value = caso;
                var parametro8 = _comandosql.Parameters.Add("@hotel", SqlDbType.Int, 0);
                parametro8.Value = hotel;



                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

        }
                                                              
        public DataTable InsertReservaciones(string CLIENTERFC, int Numeropersonas,float anticip, string Pago, string FechaI, string FechaFin, string Habitacion,string nombreH)
        {
            int caso = 1;
            DataTable LATABLAMAMA = new DataTable();
            try
            {
                conectar();
                string qry = "SP_RESERVACION";

                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 9000;

                var parametro1 = _comandosql.Parameters.Add("@rfc", SqlDbType.VarChar, 50);
                parametro1.Value = CLIENTERFC;
                var parametro2 = _comandosql.Parameters.Add("@cant_pers", SqlDbType.Int,0);
                parametro2.Value = Numeropersonas;
                var parametro3 = _comandosql.Parameters.Add("@anticipo", SqlDbType.Money,0);
                parametro3.Value = anticip;
                var parametro4 = _comandosql.Parameters.Add("@forma_pago", SqlDbType.VarChar,50);
                parametro4.Value = Pago;
                var parametro5 = _comandosql.Parameters.Add("@fecha_ini", SqlDbType.DateTime, 0);
                parametro5.Value = FechaI;
                var parametro6 = _comandosql.Parameters.Add("@fecha_fin", SqlDbType.DateTime, 0);
                parametro6.Value = FechaFin;
                var parametro7 = _comandosql.Parameters.Add("@hab", SqlDbType.VarChar, 50);
                parametro7.Value = Habitacion;
                var parametro8 = _comandosql.Parameters.Add("@clave_hotel", SqlDbType.VarChar, 50);
                parametro8.Value = nombreH;
                var parametro9 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro9.Value = caso;
              
                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(LATABLAMAMA);



            }
            catch (SqlException e)
            {

                var msg = "";
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
            finally
            {
                desconectar();
            }

            return LATABLAMAMA;
        }

                   //NUMEROR      //IDS
        public void PAGA(int NUMEROR,int idSERVICIO,int CANTIDAD)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                int caso = 8;

                conectar();
                string qry = "SP_RESERVACION";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@NUMEROR", SqlDbType.BigInt, 0);
                parametro1.Value = NUMEROR;
                var parametro2 = _comandosql.Parameters.Add("@idSERVICIO", SqlDbType.BigInt, 0);
                parametro2.Value = idSERVICIO;
                var parametro3 = _comandosql.Parameters.Add("@CANTIDAD", SqlDbType.BigInt, 0);
                parametro3.Value = CANTIDAD;
                var parametro4 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro4.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

        }
        public void FINALIZA(int str, float MONTO)
        {
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                int caso = 7;

                conectar();
                string qry = "SP_RESERVACION";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;

                var parametro1 = _comandosql.Parameters.Add("@monto", SqlDbType.Money, 0);
                parametro1.Value = MONTO;
                var parametro2 = _comandosql.Parameters.Add("@num_res", SqlDbType.Int, 0);
                parametro2.Value = str;
                var parametro4 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro4.Value = caso;

                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

        }

        public DataTable Historial(string RFC)
        {
            int caso = 1;
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SP_REPORTES";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;
                //int clave = int.Parse(CLAVEH);


                var parametro5 = _comandosql.Parameters.Add("@rfc", SqlDbType.VarChar, 50);
                parametro5.Value = RFC;

                var parametro6 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro6.Value = caso;



                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }
        public DataTable HistorialHotel(int CReservacion)
        {
            int caso = 2;
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SP_REPORTES";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;
                //int clave = int.Parse(CLAVEH);

                var parametro5 = _comandosql.Parameters.Add("@folio", SqlDbType.BigInt, 0);
                parametro5.Value = CReservacion;

               
                var parametro6 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro6.Value = caso;

                


                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }

        public DataTable ReporteV(int PAIS, string MES,int FILTRO, int opcion)
        {
           
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SP_REPORTES";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;
                //int clave = int.Parse(CLAVEH);



                var parametro4 = _comandosql.Parameters.Add("@pais", SqlDbType.BigInt, 0);
                parametro4.Value = PAIS;

                var parametro5 = _comandosql.Parameters.Add("@mes", SqlDbType.DateTime, 0);
                parametro5.Value = MES;

                var parametro6 = _comandosql.Parameters.Add("@filtro", SqlDbType.BigInt, 0);
                parametro6.Value = FILTRO;
                var parametro7 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro7.Value = opcion;



                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;






        }


        public DataTable Factura(int RFC)
        {
            int caso = 5;
            var msg = "";
            DataTable tabla = new DataTable();
            try
            {
                conectar();
                string qry = "SP_REPORTES";
                _comandosql = new SqlCommand(qry, _conexion);
                _comandosql.CommandType = CommandType.StoredProcedure;
                _comandosql.CommandTimeout = 1200;
                //int clave = int.Parse(CLAVEH);


                var parametro5 = _comandosql.Parameters.Add("@folio", SqlDbType.VarChar, 50);
                parametro5.Value = RFC;

                var parametro6 = _comandosql.Parameters.Add("@caso", SqlDbType.BigInt, 0);
                parametro6.Value = caso;



                _adaptador.SelectCommand = _comandosql;
                _adaptador.Fill(tabla);

            }
            catch (SqlException e)
            {
                msg = "Excepción de base de datos: \n";
                msg += e.Message;
                MessageBox.Show(msg, "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {
                desconectar();
            }

            return tabla;
        }

    }


}

