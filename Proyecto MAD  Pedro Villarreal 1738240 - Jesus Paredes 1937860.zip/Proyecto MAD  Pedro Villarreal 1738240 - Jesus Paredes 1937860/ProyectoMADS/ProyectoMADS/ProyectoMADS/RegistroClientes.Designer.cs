﻿namespace ProyectoMADS
{
    partial class RegistroClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.CORREO = new System.Windows.Forms.TextBox();
            this.Materno = new System.Windows.Forms.TextBox();
            this.Nombre = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Paterno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.RFC = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TELCEL = new System.Windows.Forms.TextBox();
            this.TELCASA = new System.Windows.Forms.TextBox();
            this.DESCRIPCION = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.FECHANA = new System.Windows.Forms.DateTimePicker();
            this.DOMICILIO = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(54, 409);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(216, 55);
            this.button1.TabIndex = 33;
            this.button1.Text = "Continuar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CORREO
            // 
            this.CORREO.Location = new System.Drawing.Point(54, 162);
            this.CORREO.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.CORREO.Name = "CORREO";
            this.CORREO.Size = new System.Drawing.Size(223, 20);
            this.CORREO.TabIndex = 27;
            this.CORREO.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // Materno
            // 
            this.Materno.Location = new System.Drawing.Point(54, 115);
            this.Materno.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Materno.Name = "Materno";
            this.Materno.Size = new System.Drawing.Size(223, 20);
            this.Materno.TabIndex = 25;
            this.Materno.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // Nombre
            // 
            this.Nombre.Location = new System.Drawing.Point(54, 55);
            this.Nombre.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Nombre.Name = "Nombre";
            this.Nombre.Size = new System.Drawing.Size(223, 20);
            this.Nombre.TabIndex = 23;
            this.Nombre.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(312, 145);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "Telefono de casa:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(52, 138);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Correo Electronico:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 91);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Apellido Materno";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 32);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Nombre :";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Paterno
            // 
            this.Paterno.Location = new System.Drawing.Point(313, 55);
            this.Paterno.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Paterno.Name = "Paterno";
            this.Paterno.Size = new System.Drawing.Size(218, 20);
            this.Paterno.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(310, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 32;
            this.label1.Text = "Apellido Paterno";
            // 
            // RFC
            // 
            this.RFC.Location = new System.Drawing.Point(313, 115);
            this.RFC.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RFC.Name = "RFC";
            this.RFC.Size = new System.Drawing.Size(218, 20);
            this.RFC.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(312, 91);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "RFC:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(312, 207);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 13);
            this.label5.TabIndex = 36;
            this.label5.Text = "Telefono celular:";
            // 
            // TELCEL
            // 
            this.TELCEL.Location = new System.Drawing.Point(314, 228);
            this.TELCEL.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TELCEL.Name = "TELCEL";
            this.TELCEL.Size = new System.Drawing.Size(217, 20);
            this.TELCEL.TabIndex = 30;
            // 
            // TELCASA
            // 
            this.TELCASA.Location = new System.Drawing.Point(313, 170);
            this.TELCASA.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TELCASA.Name = "TELCASA";
            this.TELCASA.Size = new System.Drawing.Size(217, 20);
            this.TELCASA.TabIndex = 28;
            // 
            // DESCRIPCION
            // 
            this.DESCRIPCION.Location = new System.Drawing.Point(54, 293);
            this.DESCRIPCION.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DESCRIPCION.Multiline = true;
            this.DESCRIPCION.Name = "DESCRIPCION";
            this.DESCRIPCION.Size = new System.Drawing.Size(223, 91);
            this.DESCRIPCION.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(52, 277);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 13);
            this.label7.TabIndex = 40;
            this.label7.Text = "¿Como conocio al hotel?:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(52, 187);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 13);
            this.label9.TabIndex = 41;
            this.label9.Text = "Fecha de nacimiento:";
            // 
            // FECHANA
            // 
            this.FECHANA.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.FECHANA.Location = new System.Drawing.Point(54, 203);
            this.FECHANA.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FECHANA.Name = "FECHANA";
            this.FECHANA.Size = new System.Drawing.Size(223, 20);
            this.FECHANA.TabIndex = 29;
            this.FECHANA.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // DOMICILIO
            // 
            this.DOMICILIO.Location = new System.Drawing.Point(54, 244);
            this.DOMICILIO.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DOMICILIO.Name = "DOMICILIO";
            this.DOMICILIO.Size = new System.Drawing.Size(223, 20);
            this.DOMICILIO.TabIndex = 31;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(52, 228);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 44;
            this.label10.Text = "Domicilio";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(313, 258);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(250, 195);
            this.dataGridView1.TabIndex = 46;
            // 
            // RegistroClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(750, 474);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.DOMICILIO);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.FECHANA);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.DESCRIPCION);
            this.Controls.Add(this.TELCASA);
            this.Controls.Add(this.TELCEL);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.RFC);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Paterno);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.CORREO);
            this.Controls.Add(this.Materno);
            this.Controls.Add(this.Nombre);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "RegistroClientes";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.RegistroClientes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox CORREO;
        private System.Windows.Forms.TextBox Materno;
        private System.Windows.Forms.TextBox Nombre;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Paterno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox RFC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TELCEL;
        private System.Windows.Forms.TextBox TELCASA;
        private System.Windows.Forms.TextBox DESCRIPCION;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker FECHANA;
        private System.Windows.Forms.TextBox DOMICILIO;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}