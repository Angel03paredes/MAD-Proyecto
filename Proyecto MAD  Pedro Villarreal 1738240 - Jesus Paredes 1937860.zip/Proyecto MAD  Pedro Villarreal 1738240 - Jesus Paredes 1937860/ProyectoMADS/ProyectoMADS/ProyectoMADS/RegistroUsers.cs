﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ProyectoMADS
{





    public partial class RegistroUsers : Form
    {
        public enlace conexion;
        public RegistroUsers()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            conexion = new enlace();
            //DataTable data = new DataTable();
            try
            {
                var usuario = textBox3.Text;
                var contra = textBox1.Text;
                var nombre = textBox5.Text;
                int nomina = int.Parse(textBox2.Text);

                var fecha = dateTimePicker1.Text;
                var domicilio = textBox6.Text;
                long telca = long.Parse(textBox7.Text);
                long telcel = long.Parse(textBox8.Text);
                conexion.insert_usuario(nombre, contra, usuario, nomina, fecha, telca, telcel, domicilio);
                textBox3.Text  = "";
                textBox1.Text= "";
                textBox5.Text= "";
                textBox2.Text = "";
                textBox6.Text = ""; 
                textBox7.Text = ""; 
                textBox8.Text = "";
                dateTimePicker1.Value = DateTime.Now;
            }
            catch ( FormatException )
            {
                MessageBox.Show("si ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }


        }

        private void btn_consulta_Click(object sender, EventArgs e)
        {
            try
            {
                conexion = new enlace();
                DataTable data = new DataTable();


                data = conexion.get_usuarios();


                dataGridView1.DataSource = data;
                conexion = null;

            }
            catch (FormatException)
            {


                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
      
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    dataGridView1.CurrentRow.Selected = true;
                    textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells["Nombre"].FormattedValue.ToString();
                    //  textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["contra"].FormattedValue.ToString();
                    textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells["Domicilio"].FormattedValue.ToString();
                    textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["Nomina"].FormattedValue.ToString();
                    textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["Apellido"].FormattedValue.ToString();
                    // dateTimePicker1.Text = dataGridView1.Rows[e.RowIndex].Cells["fecha_nac"].FormattedValue.ToString();
                    // textBox7.Text = dataGridView1.Rows[e.RowIndex].Cells["tel_casa"].FormattedValue.ToString();
                    // textBox8.Text = dataGridView1.Rows[e.RowIndex].Cells["tel_cel"].FormattedValue.ToString();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ingresa los datos correctamente. ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                conexion = new enlace();


                int nomina = int.Parse(textBox2.Text);

                conexion.Delete_users(nomina);



                conexion = null;

            }
            catch (FormatException)
            {
                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
          


        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                conexion = new enlace();
                var apellido = textBox3.Text;
                var contra = textBox1.Text;
                var nombre = textBox5.Text;
                int nomina = int.Parse(textBox2.Text);
                var fecha = dateTimePicker1.Text;
                var domicilio = textBox6.Text;
                long telca = long.Parse(textBox7.Text);
                long telcel = long.Parse(textBox8.Text);

                conexion.Actualizar_User(nombre, contra, apellido, nomina, fecha, telca, telcel, domicilio);



                conexion = null;

            }
            catch (FormatException)
            {

                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
           

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
