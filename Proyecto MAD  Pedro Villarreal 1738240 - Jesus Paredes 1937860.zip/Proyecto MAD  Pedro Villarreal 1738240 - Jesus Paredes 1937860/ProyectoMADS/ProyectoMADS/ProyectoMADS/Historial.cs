﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoMADS
{
 
    public partial class Historial : Form
    { public enlace conexion; 
        string claveh;
        public Historial()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conexion = new enlace();
                DataTable NuevaTabla = new DataTable();
                string RFC = maskedTextBox1.Text.ToString();
                NuevaTabla = conexion.Historial(RFC);


                dataGridView1.DataSource = NuevaTabla;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

        }

        private void Historial_Load(object sender, EventArgs e)
        {









        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                conexion = new enlace();
                if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    dataGridView1.CurrentRow.Selected = true;
                    claveh = dataGridView1.Rows[e.RowIndex].Cells["Folio"].FormattedValue.ToString();
                    DataTable Nueva = new DataTable();
                    int folio = int.Parse(claveh);
                    Nueva = conexion.HistorialHotel(folio);
                    dataGridView2.DataSource = Nueva;
                    conexion = null;
                }

            }
            catch (Exception ex)
            {
               
            }
        }
    }
}
