﻿namespace ProyectoMADS
{
    partial class RegistraHabitaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TCAMA = new System.Windows.Forms.ComboBox();
            this.PRECIO = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.NHABITACION = new System.Windows.Forms.ComboBox();
            this.UBICACION = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.NoCAMAS = new System.Windows.Forms.ComboBox();
            this.NOPERSONAS = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(266, 32);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Numero de camas:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 76);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tipos de cama:";
            // 
            // TCAMA
            // 
            this.TCAMA.FormattingEnabled = true;
            this.TCAMA.Items.AddRange(new object[] {
            "Individual",
            "Matrimonial",
            "Queen Size",
            "King size"});
            this.TCAMA.Location = new System.Drawing.Point(50, 93);
            this.TCAMA.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TCAMA.Name = "TCAMA";
            this.TCAMA.Size = new System.Drawing.Size(182, 21);
            this.TCAMA.TabIndex = 15;
            // 
            // PRECIO
            // 
            this.PRECIO.Location = new System.Drawing.Point(268, 95);
            this.PRECIO.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PRECIO.Name = "PRECIO";
            this.PRECIO.Size = new System.Drawing.Size(182, 20);
            this.PRECIO.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(266, 79);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Precio por noche ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(50, 32);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nivel de la habitacion";
            // 
            // NHABITACION
            // 
            this.NHABITACION.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.NHABITACION.FormattingEnabled = true;
            this.NHABITACION.Items.AddRange(new object[] {
            "Estandar",
            "De lujo",
            "Suite",
            "Master Suite",
            "Mini Suite",
            "Junior Suite",
            "Individual"});
            this.NHABITACION.Location = new System.Drawing.Point(52, 46);
            this.NHABITACION.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.NHABITACION.Name = "NHABITACION";
            this.NHABITACION.Size = new System.Drawing.Size(182, 21);
            this.NHABITACION.TabIndex = 13;
            // 
            // UBICACION
            // 
            this.UBICACION.FormattingEnabled = true;
            this.UBICACION.ItemHeight = 13;
            this.UBICACION.Items.AddRange(new object[] {
            "Frente al jardin",
            "Frente a la playa",
            "Frente a la alberca"});
            this.UBICACION.Location = new System.Drawing.Point(267, 129);
            this.UBICACION.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.UBICACION.Name = "UBICACION";
            this.UBICACION.Size = new System.Drawing.Size(182, 21);
            this.UBICACION.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(266, 115);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Ubicacion:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(50, 215);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 32);
            this.button1.TabIndex = 19;
            this.button1.Text = "Aceptar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(268, 215);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(182, 32);
            this.button2.TabIndex = 20;
            this.button2.Text = "Regresar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(49, 114);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Numero de personas";
            // 
            // NoCAMAS
            // 
            this.NoCAMAS.FormattingEnabled = true;
            this.NoCAMAS.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.NoCAMAS.Location = new System.Drawing.Point(268, 48);
            this.NoCAMAS.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.NoCAMAS.Name = "NoCAMAS";
            this.NoCAMAS.Size = new System.Drawing.Size(182, 21);
            this.NoCAMAS.TabIndex = 14;
            // 
            // NOPERSONAS
            // 
            this.NOPERSONAS.FormattingEnabled = true;
            this.NOPERSONAS.ItemHeight = 13;
            this.NOPERSONAS.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.NOPERSONAS.Location = new System.Drawing.Point(52, 129);
            this.NOPERSONAS.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.NOPERSONAS.Name = "NOPERSONAS";
            this.NOPERSONAS.Size = new System.Drawing.Size(182, 21);
            this.NOPERSONAS.TabIndex = 21;
            // 
            // RegistraHabitaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 286);
            this.Controls.Add(this.NOPERSONAS);
            this.Controls.Add(this.NoCAMAS);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.UBICACION);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.NHABITACION);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.PRECIO);
            this.Controls.Add(this.TCAMA);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "RegistraHabitaciones";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.RegistraHabitaciones_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox TCAMA;
        private System.Windows.Forms.TextBox PRECIO;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox NHABITACION;
        private System.Windows.Forms.ComboBox UBICACION;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox NoCAMAS;
        private System.Windows.Forms.ComboBox NOPERSONAS;
    }
}