﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoMADS
{
    public partial class ReporteOH : Form
    {
        public enlace conexion;
        public ReporteOH()
        {
            InitializeComponent();
        }

        private void ReporteOH_Load(object sender, EventArgs e)
        {
            try
            {

                conexion = new enlace();
                DataTable data = new DataTable();

                data = conexion.get_Pais();

                comboBox1.DataSource = data;
                // dataGridView1.DataSource = data;

                comboBox1.DisplayMember = "abrev";
                comboBox1.ValueMember = "clave_pais";
                comboBox1.Text = "";

                dateTimePicker1.Format = DateTimePickerFormat.Custom;
                dateTimePicker1.CustomFormat = "dd/MM/yyyy";

                conexion = null;


            }
            catch (FormatException)
            {
                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
            catch (ArgumentException)
            {

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
               
                conexion = new enlace();
                DataTable tabla = new DataTable();
                int opcion = 4;
                int CASO = comboBox2.SelectedIndex + 1;

                int PAISES = 0;
                PAISES = int.Parse(comboBox1.SelectedValue.ToString());
                string MES = dateTimePicker1.Text;

                tabla =conexion.ReporteV(PAISES, MES, CASO, opcion);
                dataGridView1.DataSource = tabla;


            }
            catch (FormatException)
            {

                MessageBox.Show("ERROR", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
    
        }
    }
}
