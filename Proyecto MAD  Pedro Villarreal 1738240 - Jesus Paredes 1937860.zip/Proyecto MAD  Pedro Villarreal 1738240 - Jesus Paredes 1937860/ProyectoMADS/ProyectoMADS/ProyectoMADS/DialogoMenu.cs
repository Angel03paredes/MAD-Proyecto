﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace ProyectoMADS
{
   

    public partial class DialogoMenu : Form
    {
        public bool ojo;
        public string MUESTRAUSUARIO;

        public DialogoMenu()
        {
            InitializeComponent();

            
        }
       
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (MenuVertical.Width == 300)
            {

                MenuVertical.Width = 80; ;

            } else
            {

                MenuVertical.Width = 300;
            }
        }

        private void Salir_Click(object sender, EventArgs e)
        {
            DIalogoLogin nombre = new DIalogoLogin();
            nombre.Show();
            this.Close();
        }
        private void Maxi_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            Maxi.Visible = false;
            Retaurar.Visible = true;
        }
        private void Retaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal; 
            Retaurar.Visible = false;
            Maxi.Visible = true;
        }
        private void Min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
       
        private void Tituloxd_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle,0x112,0xf012,0);
        }
        private void IBLHORA_Click(object sender, EventArgs e)
        {

        }
        private void horafecha_Tick(object sender, EventArgs e)
        {
            //IBLHORA.Text = DateTime.Now.ToString("hh:mm");
            IBLFECHA.Text = DateTime.Now.ToShortTimeString();
        }
        private void IBLFECHA_Click(object sender, EventArgs e)
        {

        } 
        private void 
            Panel(Object Formhijo)
        {
           
        }


        private void button8_Click(object sender, EventArgs e)
        { if ( label2.Text == "Administrador General")
            {
                AbrirForminPanel(new RegistroUsers());
            }
            else
            {

                MessageBox.Show("ACCESSO SOLO AL ADMINISTRADOR GENERAL ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
         
        }
        private void MenuVertical_Paint(object sender, PaintEventArgs e)
        {

        }
        private void Contenedor_Paint(object sender, PaintEventArgs e)
        {
            
        }









        private void AbrirForminPanel(Object Formhijo)
        {

            if (this.Contenedor.Controls.Count > 0)
                            this.Contenedor.Controls.RemoveAt(0);
                RegistroUsers fh = Formhijo as RegistroUsers;
                fh.TopLevel = false;
                fh.Dock = DockStyle.Fill;
                this.Contenedor.Controls.Add(fh);
                this.Contenedor.Tag = fh;
                fh.Show();
            
          
            //if (this.Contenedor.Controls.Count > 0)
            //{
            //    this.Contenedor.Controls.RemoveAt(0);
            //    RegistroClientes fh = Formhijo as RegistroClientes;
            //    fh.TopLevel = false;
            //    fh.Dock = DockStyle.Fill;
            //    this.Contenedor.Controls.Add(fh);
            //    this.Contenedor.Tag = fh;
            //    fh.Show();
            //}
            //if (this.Contenedor.Controls.Count > 0)
            //{
            //    this.Contenedor.Controls.RemoveAt(0);
            //    ResevacionesH fh = Formhijo as ResevacionesH;
            //    fh.TopLevel = false;
            //    fh.Dock = DockStyle.Fill;
            //    this.Contenedor.Controls.Add(fh);
            //    this.Contenedor.Tag = fh;
            //    fh.Show();
            //}

        }
        private void AbrirForminPanel2(Object Formhijo)
        {

            if (this.Contenedor.Controls.Count > 0)
            
                this.Contenedor.Controls.RemoveAt(0);
                RegistroHoteles fh = Formhijo as RegistroHoteles;
                fh.TopLevel = false;
                fh.Dock = DockStyle.Fill;
                this.Contenedor.Controls.Add(fh);
                this.Contenedor.Tag = fh;
                fh.Show();
            
        }
        private void AbrirForminPanel3(Object Formhijo)
        {

            if (this.Contenedor.Controls.Count > 0)
            
                this.Contenedor.Controls.RemoveAt(0);
                RegistroClientes fh = Formhijo as RegistroClientes;
                fh.TopLevel = false;
                fh.Dock = DockStyle.Fill;
                this.Contenedor.Controls.Add(fh);
                this.Contenedor.Tag = fh; 
                
                fh.Show();
            
        }
        private void AbrirForminPanel4(Object Formhijo)
        {

            if (this.Contenedor.Controls.Count > 0)
            
                this.Contenedor.Controls.RemoveAt(0);
                ResevacionesH fh = Formhijo as ResevacionesH;
                fh.TopLevel = false;
                fh.Dock = DockStyle.Fill;
                this.Contenedor.Controls.Add(fh);
                this.Contenedor.Tag = fh;
                fh.labelchingon.Text = nomina.Text;
                fh.Show();
            
        }
        private void AbrirForminPanel5(Object Formhijo)
        {

            if (this.Contenedor.Controls.Count > 0)

                this.Contenedor.Controls.RemoveAt(0);
            ReporteV fh = Formhijo as ReporteV;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.Contenedor.Controls.Add(fh);
            this.Contenedor.Tag = fh;
           
            fh.Show();

        }

        private void AbrirForminPanel6(Object Formhijo)
        {

            if (this.Contenedor.Controls.Count > 0)

                this.Contenedor.Controls.RemoveAt(0);
            Historial fh = Formhijo as Historial;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.Contenedor.Controls.Add(fh);
            this.Contenedor.Tag = fh;

            fh.Show();

        }
        private void AbrirForminPanel7(Object Formhijo)
        {

            if (this.Contenedor.Controls.Count > 0)

                this.Contenedor.Controls.RemoveAt(0);
           ReporteOH fh = Formhijo as ReporteOH;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.Contenedor.Controls.Add(fh);
            this.Contenedor.Tag = fh;

            fh.Show();

        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
          
        }
        private void button9_Click(object sender, EventArgs e)
        {
            AbrirForminPanel2(new RegistroHoteles());




        }
        private void button10_Click(object sender, EventArgs e)
        {
            AbrirForminPanel3(new RegistroClientes());
        }
        private void button11_Click(object sender, EventArgs e)
        {
            AbrirForminPanel6(new Historial());
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

            ResevacionesH INSTANCIA2 = new ResevacionesH();
            string palabra = nomina.ToString();
            INSTANCIA2.labelchingon.Text = nomina.Text;
            if (panelmini1.Visible == false)
            {

                panelmini1.Visible = true;

            }
            else
            {

                panelmini1.Visible = false;
            }
            AbrirForminPanel4(new ResevacionesH());
            
            // INSTANCIA2.labelchingon.Text = lala.Text;
          
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (label2.Text == "Administrador General")
            {
                AbrirForminPanel5(new ReporteV());

            }
            else
            {
                MessageBox.Show("ACCESSO SOLO AL ADMINISTRADOR GENERAL ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);


            }
               
            
        }

        private void button14_Click(object sender, EventArgs e)
        {
            ContraseñaL Ventana = new ContraseñaL();

            Ventana.ShowDialog();
             
           


        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            CheckOut cheka = new CheckOut();

            cheka.Show();
        }

        private void button15_Click(object sender, EventArgs e)
        {
             if (label2.Text == "Administrador General")
            {
                AbrirForminPanel7(new ReporteOH());

            }
            else
            {
                MessageBox.Show("ACCESSO SOLO AL ADMINISTRADOR GENERAL ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);


            }
         
        }

        private void Tituloxd_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DialogoMenu_Load(object sender, EventArgs e)
        {
         
        }
    }
}
