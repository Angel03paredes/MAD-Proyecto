﻿namespace ProyectoMADS
{
    partial class DialogoMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DialogoMenu));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.MenuVertical = new System.Windows.Forms.Panel();
            this.button15 = new System.Windows.Forms.Button();
            this.panelmini1 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.IBLFECHA = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button12 = new System.Windows.Forms.Button();
            this.panelmini = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BotonMenu = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.Tituloxd = new System.Windows.Forms.Panel();
            this.nomina = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Retaurar = new System.Windows.Forms.PictureBox();
            this.Maxi = new System.Windows.Forms.PictureBox();
            this.Salir = new System.Windows.Forms.PictureBox();
            this.Min = new System.Windows.Forms.PictureBox();
            this.BotonArrastra = new System.Windows.Forms.PictureBox();
            this.Contenedor = new System.Windows.Forms.Panel();
            this.horafecha = new System.Windows.Forms.Timer(this.components);
            this.MenuVertical.SuspendLayout();
            this.panelmini1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Tituloxd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Retaurar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Maxi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Salir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BotonArrastra)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(905, 123);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(265, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "Crear Usuarios";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(905, 178);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(265, 36);
            this.button2.TabIndex = 1;
            this.button2.Text = "Crear Hoteles";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(905, 230);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(265, 36);
            this.button5.TabIndex = 5;
            this.button5.Text = "Agregar habitaciones a hoteles";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(905, 288);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(265, 36);
            this.button6.TabIndex = 6;
            this.button6.Text = "Consulta de hoteles";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(905, 348);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(265, 36);
            this.button3.TabIndex = 7;
            this.button3.Text = "Ocupacion Hotelera";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(905, 404);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(265, 36);
            this.button4.TabIndex = 8;
            this.button4.Text = "Ventas";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(905, 458);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(265, 36);
            this.button7.TabIndex = 9;
            this.button7.Text = "Historial del cliente";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // MenuVertical
            // 
            this.MenuVertical.BackColor = System.Drawing.Color.Black;
            this.MenuVertical.Controls.Add(this.button15);
            this.MenuVertical.Controls.Add(this.panelmini1);
            this.MenuVertical.Controls.Add(this.panel1);
            this.MenuVertical.Controls.Add(this.label1);
            this.MenuVertical.Controls.Add(this.panel2);
            this.MenuVertical.Controls.Add(this.panelmini);
            this.MenuVertical.Controls.Add(this.pictureBox1);
            this.MenuVertical.Controls.Add(this.BotonMenu);
            this.MenuVertical.Controls.Add(this.button11);
            this.MenuVertical.Controls.Add(this.button9);
            this.MenuVertical.Controls.Add(this.button13);
            this.MenuVertical.Controls.Add(this.button10);
            this.MenuVertical.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuVertical.Location = new System.Drawing.Point(0, 0);
            this.MenuVertical.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MenuVertical.Name = "MenuVertical";
            this.MenuVertical.Size = new System.Drawing.Size(323, 629);
            this.MenuVertical.TabIndex = 10;
            this.MenuVertical.Paint += new System.Windows.Forms.PaintEventHandler(this.MenuVertical_Paint);
            // 
            // button15
            // 
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Image = ((System.Drawing.Image)(resources.GetObject("button15.Image")));
            this.button15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button15.Location = new System.Drawing.Point(9, 288);
            this.button15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(251, 39);
            this.button15.TabIndex = 14;
            this.button15.Text = "                Ocupacion por Hotel";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // panelmini1
            // 
            this.panelmini1.Controls.Add(this.button8);
            this.panelmini1.Controls.Add(this.button14);
            this.panelmini1.Location = new System.Drawing.Point(11, 432);
            this.panelmini1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelmini1.Name = "panelmini1";
            this.panelmini1.Size = new System.Drawing.Size(243, 122);
            this.panelmini1.TabIndex = 13;
            this.panelmini1.Visible = false;
            // 
            // button8
            // 
            this.button8.Dock = System.Windows.Forms.DockStyle.Top;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Image = ((System.Drawing.Image)(resources.GetObject("button8.Image")));
            this.button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.Location = new System.Drawing.Point(0, 52);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(243, 52);
            this.button8.TabIndex = 14;
            this.button8.Text = "    Check Out";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // button14
            // 
            this.button14.Dock = System.Windows.Forms.DockStyle.Top;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Image = ((System.Drawing.Image)(resources.GetObject("button14.Image")));
            this.button14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button14.Location = new System.Drawing.Point(0, 0);
            this.button14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(243, 52);
            this.button14.TabIndex = 15;
            this.button14.Text = " Check in";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this.IBLFECHA);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 585);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(323, 44);
            this.panel1.TabIndex = 13;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // IBLFECHA
            // 
            this.IBLFECHA.AutoSize = true;
            this.IBLFECHA.BackColor = System.Drawing.Color.Transparent;
            this.IBLFECHA.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IBLFECHA.ForeColor = System.Drawing.Color.White;
            this.IBLFECHA.Location = new System.Drawing.Point(0, 2);
            this.IBLFECHA.Name = "IBLFECHA";
            this.IBLFECHA.Size = new System.Drawing.Size(123, 33);
            this.IBLFECHA.TabIndex = 9;
            this.IBLFECHA.Text = "label1";
            this.IBLFECHA.Click += new System.EventHandler(this.IBLFECHA_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(271, 478);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 36);
            this.label1.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button12);
            this.panel2.Location = new System.Drawing.Point(12, 374);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(229, 55);
            this.panel2.TabIndex = 13;
            // 
            // button12
            // 
            this.button12.Dock = System.Windows.Forms.DockStyle.Top;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Image = ((System.Drawing.Image)(resources.GetObject("button12.Image")));
            this.button12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button12.Location = new System.Drawing.Point(0, 0);
            this.button12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(229, 53);
            this.button12.TabIndex = 11;
            this.button12.Text = "             Reservaciones";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // panelmini
            // 
            this.panelmini.AutoScroll = true;
            this.panelmini.Location = new System.Drawing.Point(12, 374);
            this.panelmini.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelmini.Name = "panelmini";
            this.panelmini.Size = new System.Drawing.Size(240, 180);
            this.panelmini.TabIndex = 13;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(348, 76);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // BotonMenu
            // 
            this.BotonMenu.FlatAppearance.BorderSize = 0;
            this.BotonMenu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.BotonMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BotonMenu.ForeColor = System.Drawing.Color.White;
            this.BotonMenu.Image = ((System.Drawing.Image)(resources.GetObject("BotonMenu.Image")));
            this.BotonMenu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BotonMenu.Location = new System.Drawing.Point(9, 89);
            this.BotonMenu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BotonMenu.Name = "BotonMenu";
            this.BotonMenu.Size = new System.Drawing.Size(251, 39);
            this.BotonMenu.TabIndex = 7;
            this.BotonMenu.Text = "                  Registrar Usuarios";
            this.BotonMenu.UseVisualStyleBackColor = true;
            this.BotonMenu.Click += new System.EventHandler(this.button8_Click);
            // 
            // button11
            // 
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Image = ((System.Drawing.Image)(resources.GetObject("button11.Image")));
            this.button11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button11.Location = new System.Drawing.Point(9, 245);
            this.button11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(251, 39);
            this.button11.TabIndex = 10;
            this.button11.Text = "              Historial de cliente";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button9
            // 
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.Location = new System.Drawing.Point(9, 146);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(251, 39);
            this.button9.TabIndex = 8;
            this.button9.Text = "                 Registrar Hoteles";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button13
            // 
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Image = ((System.Drawing.Image)(resources.GetObject("button13.Image")));
            this.button13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button13.Location = new System.Drawing.Point(9, 331);
            this.button13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(251, 39);
            this.button13.TabIndex = 12;
            this.button13.Text = "                Reporte de ventas";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button10
            // 
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Image = ((System.Drawing.Image)(resources.GetObject("button10.Image")));
            this.button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.Location = new System.Drawing.Point(9, 202);
            this.button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(251, 39);
            this.button10.TabIndex = 9;
            this.button10.Text = "                 Registrar Clientes";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // Tituloxd
            // 
            this.Tituloxd.Controls.Add(this.nomina);
            this.Tituloxd.Controls.Add(this.label2);
            this.Tituloxd.Controls.Add(this.Retaurar);
            this.Tituloxd.Controls.Add(this.Maxi);
            this.Tituloxd.Controls.Add(this.Salir);
            this.Tituloxd.Controls.Add(this.Min);
            this.Tituloxd.Controls.Add(this.BotonArrastra);
            this.Tituloxd.Dock = System.Windows.Forms.DockStyle.Top;
            this.Tituloxd.Location = new System.Drawing.Point(323, 0);
            this.Tituloxd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Tituloxd.Name = "Tituloxd";
            this.Tituloxd.Size = new System.Drawing.Size(977, 50);
            this.Tituloxd.TabIndex = 11;
            this.Tituloxd.Paint += new System.Windows.Forms.PaintEventHandler(this.Tituloxd_Paint);
            this.Tituloxd.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Tituloxd_MouseDown);
            // 
            // nomina
            // 
            this.nomina.AutoSize = true;
            this.nomina.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nomina.Location = new System.Drawing.Point(592, 7);
            this.nomina.Name = "nomina";
            this.nomina.Size = new System.Drawing.Size(23, 36);
            this.nomina.TabIndex = 11;
            this.nomina.Text = ".";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(67, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 36);
            this.label2.TabIndex = 10;
            this.label2.Text = ".";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Retaurar
            // 
            this.Retaurar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Retaurar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Retaurar.Image = ((System.Drawing.Image)(resources.GetObject("Retaurar.Image")));
            this.Retaurar.Location = new System.Drawing.Point(889, 1);
            this.Retaurar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Retaurar.Name = "Retaurar";
            this.Retaurar.Size = new System.Drawing.Size(40, 34);
            this.Retaurar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Retaurar.TabIndex = 2;
            this.Retaurar.TabStop = false;
            this.Retaurar.Visible = false;
            this.Retaurar.Click += new System.EventHandler(this.Retaurar_Click);
            // 
            // Maxi
            // 
            this.Maxi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Maxi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Maxi.Image = ((System.Drawing.Image)(resources.GetObject("Maxi.Image")));
            this.Maxi.Location = new System.Drawing.Point(889, 2);
            this.Maxi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Maxi.Name = "Maxi";
            this.Maxi.Size = new System.Drawing.Size(40, 34);
            this.Maxi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Maxi.TabIndex = 5;
            this.Maxi.TabStop = false;
            this.Maxi.Click += new System.EventHandler(this.Maxi_Click);
            // 
            // Salir
            // 
            this.Salir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Salir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Salir.Image = ((System.Drawing.Image)(resources.GetObject("Salir.Image")));
            this.Salir.Location = new System.Drawing.Point(937, 2);
            this.Salir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Salir.Name = "Salir";
            this.Salir.Size = new System.Drawing.Size(40, 34);
            this.Salir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Salir.TabIndex = 4;
            this.Salir.TabStop = false;
            this.Salir.Click += new System.EventHandler(this.Salir_Click);
            // 
            // Min
            // 
            this.Min.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Min.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Min.Image = ((System.Drawing.Image)(resources.GetObject("Min.Image")));
            this.Min.Location = new System.Drawing.Point(844, 2);
            this.Min.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Min.Name = "Min";
            this.Min.Size = new System.Drawing.Size(40, 34);
            this.Min.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Min.TabIndex = 3;
            this.Min.TabStop = false;
            this.Min.Click += new System.EventHandler(this.Min_Click);
            // 
            // BotonArrastra
            // 
            this.BotonArrastra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BotonArrastra.Image = ((System.Drawing.Image)(resources.GetObject("BotonArrastra.Image")));
            this.BotonArrastra.Location = new System.Drawing.Point(3, 2);
            this.BotonArrastra.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BotonArrastra.Name = "BotonArrastra";
            this.BotonArrastra.Size = new System.Drawing.Size(59, 44);
            this.BotonArrastra.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BotonArrastra.TabIndex = 0;
            this.BotonArrastra.TabStop = false;
            this.BotonArrastra.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Contenedor
            // 
            this.Contenedor.Location = new System.Drawing.Point(323, 50);
            this.Contenedor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Contenedor.Name = "Contenedor";
            this.Contenedor.Size = new System.Drawing.Size(944, 578);
            this.Contenedor.TabIndex = 12;
            this.Contenedor.Paint += new System.Windows.Forms.PaintEventHandler(this.Contenedor_Paint);
            // 
            // horafecha
            // 
            this.horafecha.Enabled = true;
            this.horafecha.Tick += new System.EventHandler(this.horafecha_Tick);
            // 
            // DialogoMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 629);
            this.Controls.Add(this.Contenedor);
            this.Controls.Add(this.Tituloxd);
            this.Controls.Add(this.MenuVertical);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "DialogoMenu";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.DialogoMenu_Load);
            this.MenuVertical.ResumeLayout(false);
            this.MenuVertical.PerformLayout();
            this.panelmini1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Tituloxd.ResumeLayout(false);
            this.Tituloxd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Retaurar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Maxi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Salir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BotonArrastra)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel MenuVertical;
        private System.Windows.Forms.PictureBox BotonArrastra;
        private System.Windows.Forms.PictureBox Retaurar;
        private System.Windows.Forms.PictureBox Salir;
        private System.Windows.Forms.PictureBox Min;
        private System.Windows.Forms.PictureBox Maxi;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BotonMenu;
        private System.Windows.Forms.Label IBLFECHA;
        private System.Windows.Forms.Timer horafecha;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Panel Contenedor;
        public System.Windows.Forms.Panel Tituloxd;
        public System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.FlowLayoutPanel panelmini;
        private System.Windows.Forms.Panel panelmini1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button14;
        public System.Windows.Forms.Label nomina;
        private System.Windows.Forms.Button button15;
    }
}