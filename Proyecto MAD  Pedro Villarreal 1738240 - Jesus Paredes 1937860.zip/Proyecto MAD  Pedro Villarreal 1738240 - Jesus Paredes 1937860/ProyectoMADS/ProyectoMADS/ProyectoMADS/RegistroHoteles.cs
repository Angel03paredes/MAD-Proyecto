﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoMADS
{
    public partial class RegistroHoteles : Form
    {
       public enlace conexion;
        string clave_h = "";
        public RegistroHoteles()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void RegistroHoteles_Load(object sender, EventArgs e)
        {
            try
            {
                conexion = new enlace();
                DataTable data = new DataTable();



                data = conexion.get_Pais();

                PAIS.DataSource = data;
                // dataGridView1.DataSource = data;

                PAIS.DisplayMember = "abrev";
                PAIS.ValueMember = "clave_pais";
                PAIS.Text = "";




                DataTable data2 = new DataTable();
                DataTable data3 = new DataTable();
                data2 = conexion.get_habitacion();
                DataRow newRow;

                List<object> list = new List<object>();
                data3.Columns.Add("Tipo", typeof(string));
                data3.Columns["Tipo"].ReadOnly = true;
                data3.Columns.Add("Precio", typeof(string));
                data3.Columns["Precio"].ReadOnly = true;
                data3.Columns.Add("Numero de camas", typeof(string));
                data3.Columns["Numero de camas"].ReadOnly = true;

                data3.Columns.Add("Cantidad", typeof(string));
                data3.Columns["Cantidad"].ReadOnly = false;
                foreach (DataRow dr in data2.Rows)
                {

                    list.Add(dr);


                }
                //  data2.Rows[0].ToString() = dataGridView1.Rows[0].

                foreach (DataRow dr in list)
                {

                    newRow = data3.NewRow();

                    newRow["Tipo"] = dr.ItemArray[0].ToString();
                    newRow["Precio"] = dr.ItemArray[1].ToString();
                    newRow["Numero de camas"] = dr.ItemArray[2].ToString();




                    //newRow["Tipo"] = dr.ItemArray[0].ToString();


                    data3.Rows.Add(newRow);
                    data3.AcceptChanges();


                }



                dataGridView1.DataSource = data3;
                //  data2.Rows[0].ToString() = dataGridView1.Rows[0].



                DataTable data4 = new DataTable();

                data4 = conexion.get_hotel();

                dataGridView2.DataSource = data4;


                conexion = null;

            }
            catch (FormatException)
            {

                MessageBox.Show("ERROR ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
            catch (ArgumentException)
            {
               
}

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                dataGridView1.CurrentRow.Selected = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            conexion = new enlace();



            try
            {
                //dataGridView1

                List<int> lista = new List<int>();
                int cantidad = dataGridView1.RowCount;
                int contador = 0;
                for(int i = 0; i <cantidad; i++)
                {
                  string var = dataGridView1.Rows[i].Cells["Cantidad"].FormattedValue.ToString();
                    if (var == "")
                        var = "0";
                    int var2 = int.Parse(var);
                    contador += var2;
                    lista.Add(var2);
                }

                int indiceNump = NUMP.SelectedIndex;
                int indicez =    ZOT.SelectedIndex;
                int indicePLA =  PLA.SelectedIndex;
                int indiceSalo = SALOND.SelectedIndex;
                int indicepisc = PISCINA.SelectedIndex;
                int caso = 1;
                int Room =  contador;


                int ELIGEP =  int.Parse(PAIS.SelectedValue.ToString());

                //  string si = comboBox1.Items[indice].ToString();

                ////////////////////////////////////////////////
                // string ZoneT = ZOT.Items[indicez].ToString();
                int Floor = int.Parse(NUMP.Items[indiceNump].ToString());
                string Beach = PLA.Items[indicePLA].ToString();
               // string PISC = PISCINA.Items[indicepisc].ToString();
                /////////////////////////////////////////////////
                string Name = NombreHotel.Text;
                string Address = Domicilio.Text;
                int City = int.Parse(Ciudad.SelectedValue.ToString());

                string DATE = dateTimePicker1.Text;
                conexion.insert_hoteles(Name, Address, City, indicez, Floor, indicePLA, ELIGEP, DATE, indicepisc, Room, caso);
            

                
                for (int i = 0; i < cantidad; i++) {
                    int veces = lista[i];
                        long hab = 5000000 + (i * 10);
                   conexion.insert_HAB(veces,hab);


                }

                DataTable data4 = new DataTable();

                data4 = conexion.get_hotel();

                dataGridView2.DataSource = data4;

                dataGridView2.Columns["Clave"].Visible   = false;

                AgregarServicios mostrar = new AgregarServicios();

                mostrar.Show();

            }


            catch (Exception ex)
            {
                MessageBox.Show("Error ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            finally
            {

                NombreHotel.Text = "";
                Domicilio.Text = "";
                NUMP.SelectedIndex = 0;
                ZOT.SelectedIndex = 0;
                PLA.SelectedIndex = 0;
                SALOND.SelectedIndex = 0;
                PISCINA.SelectedIndex = 0;


            }

        }

   

       

        private void button3_Click(object sender, EventArgs e)
        {
            conexion = new enlace();



            try
            {
                //dataGridView1

                List<int> lista = new List<int>();
                int cantidad = dataGridView1.RowCount;
                int contador = 0;
                for (int i = 0; i < cantidad; i++)
                {
                    string var = dataGridView1.Rows[i].Cells["Cantidad"].FormattedValue.ToString();
                    if (var == "")
                        var = "0";
                    int var2 = int.Parse(var);
                    contador += var2;
                    lista.Add(var2);
                }

                int indiceNump = NUMP.SelectedIndex;
                int indicez = ZOT.SelectedIndex;
                int indicePLA = PLA.SelectedIndex;
                int indiceSalo = SALOND.SelectedIndex;
                int indicepisc = PISCINA.SelectedIndex;
                int caso = 5;
                int Room = contador;


                int ELIGEP = int.Parse(PAIS.SelectedValue.ToString());


                int Floor = int.Parse(NUMP.Items[indiceNump].ToString());
                string Beach = PLA.Items[indicePLA].ToString();
             
                string Name = NombreHotel.Text;
                string Address = Domicilio.Text;
                int City = int.Parse(Ciudad.SelectedValue.ToString());

                string DATE = dateTimePicker1.Text;
                int clave = int.Parse(clave_h);

                conexion.actualizar_hoteles(Name, Address, City, indicez, Floor, indicePLA, ELIGEP, DATE, indicepisc, Room, caso,clave);
                for (int i = 0; i < cantidad; i++)
                {
                    int veces = lista[i];
                    long hab = 5000000 + (i * 10);
                    conexion.actualizar_HAB(veces, hab, clave);


                }
                DataTable data4 = new DataTable();

                data4 = conexion.get_hotel();

                dataGridView2.DataSource = data4;

                dataGridView2.Columns["Clave"].Visible = false;


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error ", "AVISO!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

        }   

        private void PAIS_SelectedIndexChanged(object sender, EventArgs e)
        {
     
            // conexion = null;
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            try
            {

                if (dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    dataGridView2.CurrentRow.Selected = true;
                    clave_h = dataGridView2.Rows[e.RowIndex].Cells["Clave"].FormattedValue.ToString();

                }


            }
            catch (FormatException){

                MessageBox.Show("ERROR ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Stop);


            }
            
                catch (ArgumentOutOfRangeException){
 
            }
            catch (ArgumentException)
            {



            }


        }

        private void Ciudad_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void PAIS_SelectionChangeCommitted(object sender, EventArgs e)
        {
            conexion = new enlace();
            DataTable data5 = new DataTable();
            int indice = int.Parse(PAIS.SelectedValue.ToString()) ;
            data5 = conexion.get_Ciudad(indice);


            Ciudad.DataSource = data5;


            Ciudad.DisplayMember = "nombre";
            Ciudad.ValueMember = "clave_ciudad";
            Ciudad.Text = "";
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegistraHabitaciones hab = new RegistraHabitaciones();
            hab.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
